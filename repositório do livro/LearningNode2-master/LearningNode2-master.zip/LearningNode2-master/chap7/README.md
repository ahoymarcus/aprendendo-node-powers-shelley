# Learning Node 2nd edition

## Updates to examples for upcoming Node.js 10 release

### Chapter 7

Examples 7-2 and 7-4 are slightly modified to add error handling. 

The new example, newhttps.js, is a new HTTPS example based on a Let's Encrypt digitical certificate. Let's Encrypt provides easy to access free digital certificates. 

So now you don't have to muck around with self-signed certificates in order to try out SSL certificates and HTTPS.

