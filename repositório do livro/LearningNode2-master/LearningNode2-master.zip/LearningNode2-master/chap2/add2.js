var base = 2;

function addtwo(input) {
   return parseInt(input) + base;
}
