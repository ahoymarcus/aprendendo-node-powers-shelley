const base = 2;

// converted code to using arrow function
exports.addTwo = (input) => parseInt(input) + base;

