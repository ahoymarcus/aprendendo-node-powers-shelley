var addtwo = require('./addtwo').addtwo;

var base = 10;

console.log(addtwo(base));
