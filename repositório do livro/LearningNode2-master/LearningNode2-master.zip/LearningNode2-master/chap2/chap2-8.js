setTimeout(function(name) {
             console.log('Hello ' + name);
           }, 3000, 'Shelley');

console.log("waiting on timer...");
