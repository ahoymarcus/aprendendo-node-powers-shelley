var base = 2;

exports.addtwo = function(input) {
  return parseInt(input) + base;
};
