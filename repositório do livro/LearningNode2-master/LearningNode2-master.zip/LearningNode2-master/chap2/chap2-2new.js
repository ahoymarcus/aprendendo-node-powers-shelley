var addTwo = require('./add2new').addTwo;

var base = 10;

console.log(addTwo(base));
