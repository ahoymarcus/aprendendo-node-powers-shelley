# Learning Node 2nd edition

## Updates to examples for upcoming Node.js 10 release

### Chapter 8

Child processes are very stable in Node, so no changes were necessary to the code. The only change I made was to remove the node_modules subdirectory. You'll need to install modern variations of modules used for the apps. 

