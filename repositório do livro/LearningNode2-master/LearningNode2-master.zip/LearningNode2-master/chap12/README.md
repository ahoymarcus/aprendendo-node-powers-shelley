# Learning Node 2nd edition

## Updates to examples for upcoming Node.js 10 release

### Chapter 12

Support for Node on smart devices continues. Node running on ChakraCore is still a work in progress, but is actively supported. So is Samsung''s IoT.js work. 

Support for Node on Arduinos and Raspberry Pi has changed little other than increased support. 

