"use strict";

if (true) {
  let sum = 100;
}

console.log(sum);
