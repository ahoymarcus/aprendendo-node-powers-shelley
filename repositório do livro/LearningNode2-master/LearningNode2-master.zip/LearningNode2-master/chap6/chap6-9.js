var path = require('path');

console.log(process.env.PATH);
console.log(process.env.PATH.split(path.delimiter));
