var mime = require('mime');
console.log(mime.getType('../images/phoenix5a.png')); // image/png
