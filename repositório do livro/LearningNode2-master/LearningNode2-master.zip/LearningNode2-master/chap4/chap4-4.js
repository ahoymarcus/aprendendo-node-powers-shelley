var val = 10.5;
var str = 'a string';

console.log('The value is %d and the string is %s', val, str);

