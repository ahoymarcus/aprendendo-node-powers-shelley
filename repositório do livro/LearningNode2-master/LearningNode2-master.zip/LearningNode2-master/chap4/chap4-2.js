// log messages
console.log('this is informative');
console.info('this is more information');

// error messages
console.error('this is an error');
console.warn('but this is only a warning');
